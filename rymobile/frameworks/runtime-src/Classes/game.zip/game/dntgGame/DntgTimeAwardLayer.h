#ifndef _Dntg_TimeAwardLayer_H_
#define _Dntg_TimeAwardLayer_H_


#endif // _TimeAwardLayer_H_